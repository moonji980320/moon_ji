package checkEmpty;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class checkEmpty
 */
@WebServlet("/checkEmpty")
public class checkEmpty extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public checkEmpty() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String pwd = request.getParameter("pwd");
		if ((name != null && !name.equals("")) && (pwd!= null && !pwd.equals("")))
		{ // 빈칸이 아닐경우(로그인시도)
			request.getRequestDispatcher("join.jsp").forward(request, response);
		}
		else { // 빈칸일 경우
			request.getRequestDispatcher("main.jsp").forward(request, response);
		}
	}

}
